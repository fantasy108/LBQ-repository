/*Javascript*/

$(function () {
    // var w_height = $('.game img').height()
    // $('.game').css('height',w_height)
    

})



